import { useState } from "react";
import { getSigner } from "../utils/contract.js";
import { connectP2P } from "../utils/libp2p.js";

export default function ConnectWallet({ onConnected }) {
  const [connecting, setConnecting] = useState(false);
  const [error, setError]           = useState("");

  async function handleConnect() {
    setConnecting(true);
    setError("");
    try {
      const signer  = await getSigner();
      const address = await signer.getAddress();
      connectP2P(address);
      onConnected(signer, address);
    } catch (e) {
      setError("Failed to connect wallet: " + e.message);
    } finally {
      setConnecting(false);
    }
  }

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>DataAuth</h1>
      <p style={styles.subtitle}>Blockchain-based P2P File Authentication</p>
      <button onClick={handleConnect} disabled={connecting} style={styles.btn}>
        {connecting ? "Connecting..." : "Connect Wallet"}
      </button>
      {error && <p style={styles.error}>{error}</p>}
    </div>
  );
}

const styles = {
  container: {
    display: "flex", flexDirection: "column", alignItems: "center",
    justifyContent: "center", height: "100vh", gap: "16px",
    fontFamily: "sans-serif",
  },
  title:    { fontSize: "2rem", margin: 0 },
  subtitle: { color: "#666", margin: 0 },
  btn: {
    padding: "12px 32px", fontSize: "1rem", background: "#2563eb",
    color: "#fff", border: "none", borderRadius: "8px", cursor: "pointer",
  },
  error: { color: "red" },
};
