import { useState, useEffect } from "react";
import { getReadOnlyContract } from "../utils/contract.js";

const STATUS_COLORS = {
  PENDING:  "#d97706",
  ACCEPTED: "#16a34a",
  REJECTED: "#6b7280",
  TAMPERED: "#dc2626",
};

export default function TransactionHistory({ myAddress }) {
  const [records,  setRecords]  = useState([]);
  const [loading,  setLoading]  = useState(true);

  useEffect(() => { fetchRecords(); }, []);

  async function fetchRecords() {
    setLoading(true);
    try {
      const contract = getReadOnlyContract();
      const count    = await contract.recordCount();
      const results  = [];

      for (let i = 0; i < Number(count); i++) {
        const r = await contract.records(i);
        // Only show records involving this address
        if (
          r.sender.toLowerCase()   === myAddress.toLowerCase() ||
          r.receiver.toLowerCase() === myAddress.toLowerCase()
        ) {
          results.push({
            id:        i,
            sender:    r.sender,
            receiver:  r.receiver,
            fileHash:  r.fileHash,
            timestamp: Number(r.timestamp),
            status:    r.status,
          });
        }
      }
      setRecords(results.reverse()); // newest first
    } catch (e) {
      console.error("Failed to fetch records", e);
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <p style={{ padding: "24px" }}>Loading transactions...</p>;
  if (!records.length) return <p style={{ padding: "24px", color: "#9ca3af" }}>No transactions yet.</p>;

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2 style={{ margin: 0 }}>Transaction History</h2>
        <button onClick={fetchRecords} style={styles.refresh}>↻ Refresh</button>
      </div>

      {records.map(r => (
        <div key={r.id} style={styles.card}>
          <div style={styles.row}>
            <span style={styles.id}>#{r.id}</span>
            <span style={{ ...styles.badge, background: STATUS_COLORS[r.status] || "#6b7280" }}>
              {r.status}
            </span>
          </div>
          <p style={styles.field}>
            <strong>From:</strong> <code>{r.sender}</code>
          </p>
          <p style={styles.field}>
            <strong>To:</strong> <code>{r.receiver}</code>
          </p>
          <p style={styles.field}>
            <strong>Hash:</strong> <code>{r.fileHash.slice(0, 30)}...</code>
          </p>
          <p style={styles.field}>
            <strong>Time:</strong> {new Date(r.timestamp * 1000).toLocaleString()}
          </p>
        </div>
      ))}
    </div>
  );
}

const styles = {
  container: { padding: "24px" },
  header:    { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" },
  refresh:   { padding: "6px 16px", border: "1px solid #d1d5db", borderRadius: "6px",
               background: "#fff", cursor: "pointer", fontSize: "13px" },
  card:      { background: "#f9fafb", border: "1px solid #e5e7eb", borderRadius: "10px",
               padding: "16px", marginBottom: "12px" },
  row:       { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" },
  id:        { fontWeight: "600", fontSize: "14px" },
  badge:     { color: "#fff", padding: "2px 10px", borderRadius: "99px", fontSize: "12px", fontWeight: "500" },
  field:     { margin: "4px 0", fontSize: "13px", color: "#374151" },
};
