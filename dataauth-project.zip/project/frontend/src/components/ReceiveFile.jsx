import { useEffect, useState } from "react";
import { getContract } from "../utils/contract.js";
import { hashContent } from "../utils/hash.js";
import { buildReceiverMessage, signMessage, generateNonce } from "../utils/sign.js";
import { onFileReceived } from "../utils/libp2p.js";

export default function ReceiveFile({ signer, myAddress }) {
  const [incoming,  setIncoming]  = useState(null);  // { recordID, fileContent, from }
  const [record,    setRecord]    = useState(null);   // on-chain record
  const [hashMatch, setHashMatch] = useState(null);   // true | false
  const [loading,   setLoading]   = useState(false);
  const [result,    setResult]    = useState("");

  // Listen for incoming files via P2P
  useEffect(() => {
    onFileReceived(async (payload) => {
      setIncoming(payload);
      setResult("");

      // Fetch on-chain record
      try {
        const contract = await getContract();
        const rec      = await contract.records(payload.recordID);
        setRecord(rec);

        // Hash comparison
        const receivedHash = hashContent(payload.fileContent);
        const onChainHash  = rec.fileHash;
        setHashMatch(receivedHash === onChainHash);
      } catch (e) {
        setResult("❌ Failed to fetch record: " + e.message);
      }
    });
  }, []);

  async function handleAck(status) {
    setLoading(true);
    setResult("");
    try {
      const contract     = await getContract();
      const receivedHash = hashContent(incoming.fileContent);
      const nonce        = generateNonce();
      const timestamp    = Math.floor(Date.now() / 1000);

      const message = buildReceiverMessage(
        receivedHash,
        incoming.recordID,
        status,
        nonce,
        timestamp
      );
      const sig = await signMessage(signer, message);

      const tx = await contract.acknowledge(
        incoming.recordID,
        receivedHash,
        status,
        nonce,
        timestamp,
        sig
      );
      setResult("Waiting for mining...");
      await tx.wait();
      setResult(`✅ ${status}. Transaction confirmed.`);
      setIncoming(null);
      setRecord(null);
      setHashMatch(null);
    } catch (e) {
      setResult("❌ Error: " + e.message);
    } finally {
      setLoading(false);
    }
  }

  // TAMPERED — show alert, no popup
  if (incoming && hashMatch === false) {
    return (
      <div style={styles.tampered}>
        <h2>⚠️ TAMPERED FILE DETECTED</h2>
        <p>A file was received from <code>{incoming.from}</code> but its hash does not match what was recorded on the blockchain.</p>
        <p>This file has been tampered with. Transaction rejected.</p>
        <button style={styles.btnDanger} onClick={() => { setIncoming(null); setHashMatch(null); }}>
          Dismiss
        </button>
      </div>
    );
  }

  // ACCEPT / REJECT popup
  if (incoming && hashMatch === true && record) {
    return (
      <div style={styles.overlay}>
        <div style={styles.popup}>
          <h2 style={{ margin: "0 0 8px" }}>📩 Incoming File</h2>
          <p style={styles.meta}>From: <code>{record.sender}</code></p>
          <p style={styles.meta}>Record ID: <code>{incoming.recordID}</code></p>
          <p style={styles.meta}>Hash verified: <span style={{ color: "green" }}>✅ Matches blockchain</span></p>

          <div style={styles.preview}>
            <strong>File Preview:</strong>
            <pre style={styles.pre}>{incoming.fileContent.slice(0, 500)}</pre>
          </div>

          <div style={styles.actions}>
            <button
              style={{ ...styles.btn, background: "#16a34a" }}
              disabled={loading}
              onClick={() => handleAck("ACCEPTED")}
            >
              ✅ Accept
            </button>
            <button
              style={{ ...styles.btn, background: "#dc2626" }}
              disabled={loading}
              onClick={() => handleAck("REJECTED")}
            >
              ❌ Reject
            </button>
          </div>

          {result && <p style={styles.result}>{result}</p>}
        </div>
      </div>
    );
  }

  // Idle state — waiting for incoming files
  return (
    <div style={styles.idle}>
      <h2>Receiver</h2>
      <p style={{ color: "#6b7280" }}>Your address: <code>{myAddress}</code></p>
      <p style={{ color: "#9ca3af" }}>⏳ Listening for incoming files...</p>
      {result && <p>{result}</p>}
    </div>
  );
}

const styles = {
  idle: { padding: "24px" },
  overlay: {
    position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)",
    display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100,
  },
  popup: {
    background: "#fff", borderRadius: "12px", padding: "28px",
    maxWidth: "500px", width: "90%", boxShadow: "0 20px 60px rgba(0,0,0,0.2)",
  },
  meta:    { fontSize: "13px", color: "#374151", margin: "4px 0" },
  preview: { margin: "16px 0", background: "#f3f4f6", borderRadius: "6px", padding: "12px" },
  pre:     { margin: 0, fontSize: "12px", whiteSpace: "pre-wrap", wordBreak: "break-all" },
  actions: { display: "flex", gap: "12px", marginTop: "16px" },
  btn: {
    flex: 1, padding: "12px", color: "#fff", border: "none",
    borderRadius: "6px", fontSize: "14px", cursor: "pointer", fontWeight: "500",
  },
  result:  { marginTop: "12px", fontSize: "13px" },
  tampered: {
    margin: "24px", padding: "24px", background: "#fef2f2",
    border: "2px solid #dc2626", borderRadius: "12px",
  },
  btnDanger: {
    marginTop: "12px", padding: "10px 24px", background: "#dc2626",
    color: "#fff", border: "none", borderRadius: "6px", cursor: "pointer",
  },
};
