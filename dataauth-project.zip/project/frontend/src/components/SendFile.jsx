import { useState } from "react";
import { getContract } from "../utils/contract.js";
import { readFileContent, hashContent } from "../utils/hash.js";
import { buildSenderMessage, signMessage, generateNonce } from "../utils/sign.js";
import { sendFileP2P } from "../utils/libp2p.js";

export default function SendFile({ signer, myAddress }) {
  const [receiver,    setReceiver]    = useState("");
  const [file,        setFile]        = useState(null);
  const [status,      setStatus]      = useState("");
  const [loading,     setLoading]     = useState(false);
  const [txHash,      setTxHash]      = useState("");

  async function handleSend() {
    if (!receiver || !file) {
      setStatus("Please enter receiver address and select a file.");
      return;
    }

    setLoading(true);
    setStatus("");
    setTxHash("");

    try {
      // 1. Read file content
      setStatus("Reading file...");
      const content   = await readFileContent(file);

      // 2. Hash the content
      const fileHash  = hashContent(content);
      setStatus("File hashed: " + fileHash.slice(0, 20) + "...");

      // 3. Build and sign the message
      const nonce     = generateNonce();
      const timestamp = Math.floor(Date.now() / 1000);
      const message   = buildSenderMessage(fileHash, receiver, nonce, timestamp);
      const sig       = await signMessage(signer, message);
      setStatus("Message signed. Broadcasting to blockchain...");

      // 4. Call smart contract
      const contract  = await getContract();
      const tx        = await contract.sendFile(receiver, fileHash, nonce, timestamp, sig);
      setStatus("Transaction sent. Waiting for mining...");

      // 5. Wait for mining, get recordID from event
      const receipt   = await tx.wait();
      setTxHash(tx.hash);

      const iface  = contract.interface;
      const log    = receipt.logs.find(l => {
        try { return iface.parseLog(l).name === "FileSent"; } catch { return false; }
      });
      const recordID = iface.parseLog(log).args.id;
      setStatus(`Mined! Record ID: ${recordID}. Sending file to receiver...`);

      // 6. Send file content off-chain via P2P
      sendFileP2P(receiver, {
        recordID:    recordID.toString(),
        fileContent: content,
        from:        myAddress,
      });

      setStatus(`✅ Done! File sent. Record ID: ${recordID}`);
    } catch (e) {
      setStatus("❌ Error: " + e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.card}>
      <h2 style={styles.heading}>Send File</h2>
      <p style={styles.label}>Your address: <code>{myAddress}</code></p>

      <input
        style={styles.input}
        placeholder="Receiver wallet address (0x...)"
        value={receiver}
        onChange={e => setReceiver(e.target.value)}
      />

      <input
        style={styles.input}
        type="file"
        accept=".txt"
        onChange={e => setFile(e.target.files[0])}
      />

      <button onClick={handleSend} disabled={loading} style={styles.btn}>
        {loading ? "Sending..." : "Send File"}
      </button>

      {status  && <p style={styles.status}>{status}</p>}
      {txHash  && <p style={styles.hash}>Tx: <code>{txHash}</code></p>}
    </div>
  );
}

const styles = {
  card:    { background: "#f9fafb", padding: "24px", borderRadius: "12px", maxWidth: "560px" },
  heading: { margin: "0 0 16px" },
  label:   { fontSize: "13px", color: "#555", marginBottom: "12px" },
  input:   { display: "block", width: "100%", padding: "10px", marginBottom: "12px",
             border: "1px solid #d1d5db", borderRadius: "6px", fontSize: "14px", boxSizing: "border-box" },
  btn:     { padding: "10px 28px", background: "#2563eb", color: "#fff",
             border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "14px" },
  status:  { marginTop: "12px", fontSize: "13px", color: "#374151" },
  hash:    { fontSize: "11px", color: "#6b7280", wordBreak: "break-all" },
};
