// Copy this from blockchain/artifacts/contracts/DataAuth.sol/DataAuth.json after compiling
// This is the ABI only — the part ethers.js needs to talk to the contract

const ABI = [
  "function sendFile(address receiver, bytes32 fileHash, uint256 nonce, uint256 timestamp, bytes sig) public",
  "function acknowledge(uint256 id, bytes32 receivedHash, string status, uint256 nonce, uint256 timestamp, bytes sig) public",
  "function records(uint256 id) public view returns (address sender, address receiver, bytes32 fileHash, uint256 timestamp, uint256 senderNonce, bytes senderSig, string status)",
  "function recordCount() public view returns (uint256)",
  "function getPendingForReceiver() public view returns (uint256[])",
  "function isNonceUsed(address wallet, uint256 nonce) public view returns (bool)",
  "event FileSent(uint256 indexed id, address indexed sender, address indexed receiver, bytes32 fileHash, uint256 timestamp)",
  "event FileAcknowledged(uint256 indexed id, address indexed receiver, string status)"
];

export default ABI;
