import { ethers } from "ethers";
import ABI from "../contracts/DataAuth.js";
import { CONTRACT_ADDRESS } from "../contracts/address.js";

// Returns a provider connected to local Hardhat network
export function getProvider() {
  return new ethers.JsonRpcProvider("http://127.0.0.1:8545");
}

// Returns a signer (wallet) from the browser — or from a private key for testing
export async function getSigner() {
  if (typeof window !== "undefined" && window.ethereum) {
    // Browser wallet (MetaMask or similar)
    const provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    return provider.getSigner();
  }
  // Fallback: use first Hardhat account (testing only)
  const provider = getProvider();
  return provider.getSigner();
}

// Returns contract instance connected to a signer (can send transactions)
export async function getContract() {
  const signer = await getSigner();
  return new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);
}

// Returns contract instance connected to a provider (read-only)
export function getReadOnlyContract() {
  const provider = getProvider();
  return new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);
}
