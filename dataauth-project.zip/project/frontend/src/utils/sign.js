import { ethers } from "ethers";

// Builds the message sender must sign:
// keccak256(fileHash + receiverAddress + nonce + timestamp)
export function buildSenderMessage(fileHash, receiverAddress, nonce, timestamp) {
  return ethers.keccak256(
    ethers.solidityPacked(
      ["bytes32", "address", "uint256", "uint256"],
      [fileHash, receiverAddress, nonce, timestamp]
    )
  );
}

// Builds the message receiver must sign:
// keccak256(receivedHash + recordID + status + nonce + timestamp)
export function buildReceiverMessage(receivedHash, recordId, status, nonce, timestamp) {
  return ethers.keccak256(
    ethers.solidityPacked(
      ["bytes32", "uint256", "string", "uint256", "uint256"],
      [receivedHash, recordId, status, nonce, timestamp]
    )
  );
}

// Signs a message with the given signer's private key
// Returns the signature hex string
export async function signMessage(signer, message) {
  return signer.signMessage(ethers.getBytes(message));
}

// Generates a random nonce (large random number)
export function generateNonce() {
  return Math.floor(Math.random() * 1_000_000_000);
}
