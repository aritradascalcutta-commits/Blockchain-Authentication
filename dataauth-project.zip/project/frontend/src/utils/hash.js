import { ethers } from "ethers";

// Reads a txt File object and returns its content as a string
export function readFileContent(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = (e) => resolve(e.target.result);
    reader.onerror = ()  => reject(new Error("Failed to read file"));
    reader.readAsText(file);
  });
}

// Hashes a string using keccak256 (same as Solidity's keccak256)
// Returns a bytes32 hex string e.g. "0xabc123..."
export function hashContent(content) {
  return ethers.keccak256(ethers.toUtf8Bytes(content));
}
