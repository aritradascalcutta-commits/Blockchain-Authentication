// ─────────────────────────────────────────────────────────────
// P2P File Transfer using WebSockets
//
// In a real P2P setup this would use libp2p.
// For this project we simulate P2P using a lightweight
// WebSocket relay — each node connects to ws://localhost:3001
// and messages are routed by receiver address.
//
// To run the relay:  node relay.js  (see relay.js in project root)
// ─────────────────────────────────────────────────────────────

let socket = null;
let messageHandler = null;

// Connect this node to the P2P relay
export function connectP2P(myAddress) {
  if (socket) return; // already connected

  socket = new WebSocket("ws://localhost:3001");

  socket.onopen = () => {
    // Register this node's wallet address with the relay
    socket.send(JSON.stringify({
      type: "REGISTER",
      address: myAddress,
    }));
    console.log("[P2P] Connected and registered as", myAddress);
  };

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === "FILE_TRANSFER" && messageHandler) {
        messageHandler(data.payload); // { recordID, fileContent, from }
      }
    } catch (e) {
      console.error("[P2P] Failed to parse message", e);
    }
  };

  socket.onerror = (e) => console.error("[P2P] WebSocket error", e);
  socket.onclose = ()  => { socket = null; console.log("[P2P] Disconnected"); };
}

// Send file content to receiver via P2P relay
export function sendFileP2P(toAddress, payload) {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    throw new Error("P2P not connected");
  }
  socket.send(JSON.stringify({
    type: "FILE_TRANSFER",
    to: toAddress,
    payload, // { recordID, fileContent, from }
  }));
  console.log("[P2P] File sent to", toAddress);
}

// Register a callback to handle incoming file transfers
// callback receives: { recordID, fileContent, from }
export function onFileReceived(callback) {
  messageHandler = callback;
}

// Disconnect from relay
export function disconnectP2P() {
  if (socket) { socket.close(); socket = null; }
}
