import { useState } from "react";
import ConnectWallet      from "./components/ConnectWallet.jsx";
import SendFile           from "./components/SendFile.jsx";
import ReceiveFile        from "./components/ReceiveFile.jsx";
import TransactionHistory from "./components/TransactionHistory.jsx";

const TABS = ["Send", "Receive", "History"];

export default function App() {
  const [signer,    setSigner]    = useState(null);
  const [myAddress, setMyAddress] = useState("");
  const [tab,       setTab]       = useState("Send");

  if (!signer) {
    return (
      <ConnectWallet
        onConnected={(s, addr) => { setSigner(s); setMyAddress(addr); }}
      />
    );
  }

  return (
    <div style={styles.app}>
      <header style={styles.header}>
        <h1 style={styles.logo}>🔐 DataAuth</h1>
        <code style={styles.addr}>{myAddress.slice(0, 6)}...{myAddress.slice(-4)}</code>
      </header>

      <nav style={styles.nav}>
        {TABS.map(t => (
          <button
            key={t}
            style={{ ...styles.tab, ...(tab === t ? styles.tabActive : {}) }}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </nav>

      <main style={styles.main}>
        {tab === "Send"    && <SendFile    signer={signer} myAddress={myAddress} />}
        {tab === "Receive" && <ReceiveFile signer={signer} myAddress={myAddress} />}
        {tab === "History" && <TransactionHistory myAddress={myAddress} />}
      </main>
    </div>
  );
}

const styles = {
  app:    { fontFamily: "sans-serif", maxWidth: "700px", margin: "0 auto", padding: "0 16px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center",
            padding: "16px 0", borderBottom: "1px solid #e5e7eb" },
  logo:   { margin: 0, fontSize: "1.4rem" },
  addr:   { background: "#f3f4f6", padding: "4px 10px", borderRadius: "6px",
            fontSize: "12px", color: "#374151" },
  nav:    { display: "flex", gap: "4px", padding: "16px 0" },
  tab:    { padding: "8px 20px", border: "1px solid #d1d5db", borderRadius: "6px",
            background: "#fff", cursor: "pointer", fontSize: "14px", color: "#374151" },
  tabActive: { background: "#2563eb", color: "#fff", border: "1px solid #2563eb" },
  main:   { paddingBottom: "48px" },
};
