# DataAuth — Blockchain P2P File Authentication

A decentralized file authentication system where:
- Files are transferred **off-chain** (P2P via WebSocket relay)
- File hashes, signatures, and acknowledgements are stored **on-chain** (Ethereum / Hardhat)
- No central server — every node runs the same app

---

## How It Works

1. **Sender** selects a `.txt` file and enters receiver's wallet address
2. Sender's app hashes the file, signs the hash, and calls `sendFile()` on the smart contract
3. Smart contract verifies the signature and stores the record on-chain
4. Sender's app sends the actual file content to receiver via P2P (off-chain)
5. **Receiver** gets the file, hashes it locally, compares with on-chain hash
6. If hashes match → ACCEPT/REJECT popup shown
7. If hashes don't match → TAMPERED alert shown
8. Receiver's decision is broadcast on-chain via `acknowledge()`

---

## Tech Stack

| Layer | Technology |
|---|---|
| Blockchain | Ethereum (local Hardhat network) |
| Smart Contract | Solidity + OpenZeppelin |
| Blockchain interaction | ethers.js v6 |
| Frontend | React + Vite |
| P2P transfer | WebSocket relay (simulates libp2p) |
| Hashing | keccak256 (ethers.js) |

---

## Project Structure

```
project/
├── blockchain/
│   ├── contracts/DataAuth.sol     ← Smart contract
│   ├── scripts/deploy.js          ← Deploy script
│   ├── test/DataAuth.js           ← Contract tests
│   └── hardhat.config.js
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ConnectWallet.jsx
│   │   │   ├── SendFile.jsx
│   │   │   ├── ReceiveFile.jsx
│   │   │   └── TransactionHistory.jsx
│   │   ├── utils/
│   │   │   ├── contract.js        ← ethers.js setup
│   │   │   ├── hash.js            ← hashing utility
│   │   │   ├── sign.js            ← signing utility
│   │   │   └── libp2p.js          ← P2P utility
│   │   └── contracts/
│   │       ├── DataAuth.js        ← Contract ABI
│   │       └── address.js         ← Deployed contract address
│   └── vite.config.js
└── relay.js                       ← WebSocket relay (P2P simulation)
```

---

## Setup & Running

### Prerequisites
- Node.js v18+
- A browser wallet (or use Hardhat's built-in accounts)

---

### Step 1 — Install blockchain dependencies
```bash
cd blockchain
npm install
```

### Step 2 — Compile the smart contract
```bash
npx hardhat compile
```

### Step 3 — Start local blockchain (keep this terminal open)
```bash
npx hardhat node
```

### Step 4 — Deploy contract (new terminal)
```bash
npx hardhat run scripts/deploy.js --network localhost
```
Copy the printed address and paste it into `frontend/src/contracts/address.js`

### Step 5 — Run contract tests
```bash
npx hardhat test
```

### Step 6 — Start P2P relay (new terminal)
```bash
node relay.js
```

### Step 7 — Start frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```

### Step 8 — Open two browser tabs
- Tab 1 = Node A (Sender)
- Tab 2 = Node B (Receiver)
- Connect different Hardhat wallets in each tab

---

## Smart Contract Functions

| Function | Called by | What it does |
|---|---|---|
| `sendFile()` | Sender | Verifies sender signature, stores record, emits FileSent event |
| `acknowledge()` | Receiver | Verifies receiver signature, compares hashes on-chain, updates status |
| `getPendingForReceiver()` | Anyone | Returns pending record IDs for caller |
| `isNonceUsed()` | Frontend | Checks if a nonce has been used |

## Record Statuses

| Status | Meaning |
|---|---|
| PENDING | File sent, waiting for receiver |
| ACCEPTED | Receiver accepted, hashes matched |
| REJECTED | Receiver explicitly rejected |
| TAMPERED | Hash mismatch detected on-chain |
