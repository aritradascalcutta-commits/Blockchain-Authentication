// relay.js — Simple WebSocket relay for P2P simulation
// Run with: node relay.js
// Each node connects here and registers its wallet address.
// Messages are routed to the correct recipient by address.

const { WebSocketServer } = require("ws");

const wss = new WebSocketServer({ port: 3001 });

// Map: walletAddress (lowercase) => WebSocket connection
const clients = new Map();

wss.on("connection", (ws) => {
  let myAddress = null;

  ws.on("message", (raw) => {
    try {
      const msg = JSON.parse(raw);

      if (msg.type === "REGISTER") {
        myAddress = msg.address.toLowerCase();
        clients.set(myAddress, ws);
        console.log("[Relay] Registered:", myAddress);
        return;
      }

      if (msg.type === "FILE_TRANSFER") {
        const target = msg.to?.toLowerCase();
        const targetWs = clients.get(target);

        if (targetWs && targetWs.readyState === 1) {
          targetWs.send(JSON.stringify({
            type:    "FILE_TRANSFER",
            payload: msg.payload,
          }));
          console.log("[Relay] Routed file from", myAddress, "to", target);
        } else {
          console.warn("[Relay] Target not connected:", target);
        }
      }
    } catch (e) {
      console.error("[Relay] Error:", e.message);
    }
  });

  ws.on("close", () => {
    if (myAddress) {
      clients.delete(myAddress);
      console.log("[Relay] Disconnected:", myAddress);
    }
  });
});

console.log("[Relay] WebSocket relay running on ws://localhost:3001");
