const { expect } = require("chai");
const { ethers } = require("hardhat");

function hashFile(content) {
  return ethers.keccak256(ethers.toUtf8Bytes(content));
}

async function buildSenderMessage(fileHash, receiverAddress, nonce, timestamp) {
  return ethers.keccak256(
    ethers.solidityPacked(
      ["bytes32", "address", "uint256", "uint256"],
      [fileHash, receiverAddress, nonce, timestamp]
    )
  );
}

async function buildReceiverMessage(receivedHash, id, status, nonce, timestamp) {
  return ethers.keccak256(
    ethers.solidityPacked(
      ["bytes32", "uint256", "string", "uint256", "uint256"],
      [receivedHash, id, status, nonce, timestamp]
    )
  );
}

describe("DataAuth", function () {
  let dataAuth, sender, receiver, stranger;

  beforeEach(async function () {
    [sender, receiver, stranger] = await ethers.getSigners();
    const DataAuth = await ethers.getContractFactory("DataAuth");
    dataAuth = await DataAuth.deploy();
    await dataAuth.waitForDeployment();
  });

  async function doSendFile(fileContent, senderNonce) {
    const fileHash  = hashFile(fileContent);
    const timestamp = Math.floor(Date.now() / 1000);
    const message   = await buildSenderMessage(fileHash, receiver.address, senderNonce, timestamp);
    const sig       = await sender.signMessage(ethers.getBytes(message));
    const tx        = await dataAuth.connect(sender).sendFile(receiver.address, fileHash, senderNonce, timestamp, sig);
    const receipt   = await tx.wait();
    const event     = receipt.logs.find(log => {
      try { return dataAuth.interface.parseLog(log).name === "FileSent"; } catch { return false; }
    });
    return dataAuth.interface.parseLog(event).args.id;
  }

  describe("sendFile()", function () {
    it("stores record and emits FileSent", async function () {
      const fileHash  = hashFile("Hello txt file");
      const nonce     = 1;
      const timestamp = Math.floor(Date.now() / 1000);
      const message   = await buildSenderMessage(fileHash, receiver.address, nonce, timestamp);
      const sig       = await sender.signMessage(ethers.getBytes(message));

      await expect(dataAuth.connect(sender).sendFile(receiver.address, fileHash, nonce, timestamp, sig))
        .to.emit(dataAuth, "FileSent")
        .withArgs(0, sender.address, receiver.address, fileHash, timestamp);

      const record = await dataAuth.records(0);
      expect(record.sender).to.equal(sender.address);
      expect(record.receiver).to.equal(receiver.address);
      expect(record.status).to.equal("PENDING");
    });

    it("rejects reused nonce", async function () {
      const fileHash  = hashFile("file");
      const nonce     = 1;
      const timestamp = Math.floor(Date.now() / 1000);
      const message   = await buildSenderMessage(fileHash, receiver.address, nonce, timestamp);
      const sig       = await sender.signMessage(ethers.getBytes(message));

      await dataAuth.connect(sender).sendFile(receiver.address, fileHash, nonce, timestamp, sig);
      await expect(dataAuth.connect(sender).sendFile(receiver.address, fileHash, nonce, timestamp, sig))
        .to.be.revertedWith("Nonce already used");
    });

    it("rejects invalid signature", async function () {
      const fileHash  = hashFile("file");
      const nonce     = 1;
      const timestamp = Math.floor(Date.now() / 1000);
      const message   = await buildSenderMessage(fileHash, receiver.address, nonce, timestamp);
      const wrongSig  = await stranger.signMessage(ethers.getBytes(message));

      await expect(dataAuth.connect(sender).sendFile(receiver.address, fileHash, nonce, timestamp, wrongSig))
        .to.be.revertedWith("Invalid sender signature");
    });

    it("rejects zero address receiver", async function () {
      const fileHash  = hashFile("file");
      const nonce     = 1;
      const timestamp = Math.floor(Date.now() / 1000);
      const message   = await buildSenderMessage(fileHash, ethers.ZeroAddress, nonce, timestamp);
      const sig       = await sender.signMessage(ethers.getBytes(message));

      await expect(dataAuth.connect(sender).sendFile(ethers.ZeroAddress, fileHash, nonce, timestamp, sig))
        .to.be.revertedWith("Invalid receiver");
    });
  });

  describe("acknowledge()", function () {
    it("accepts file and sets ACCEPTED", async function () {
      const content      = "Hello txt file";
      const id           = await doSendFile(content, 1);
      const receivedHash = hashFile(content);
      const nonce        = 10;
      const timestamp    = Math.floor(Date.now() / 1000);
      const status       = "ACCEPTED";
      const message      = await buildReceiverMessage(receivedHash, id, status, nonce, timestamp);
      const sig          = await receiver.signMessage(ethers.getBytes(message));

      await expect(dataAuth.connect(receiver).acknowledge(id, receivedHash, status, nonce, timestamp, sig))
        .to.emit(dataAuth, "FileAcknowledged")
        .withArgs(id, receiver.address, "ACCEPTED");

      expect((await dataAuth.records(id)).status).to.equal("ACCEPTED");
    });

    it("marks TAMPERED if hash does not match", async function () {
      const id           = await doSendFile("original", 1);
      const tamperedHash = hashFile("tampered");
      const nonce        = 10;
      const timestamp    = Math.floor(Date.now() / 1000);
      const status       = "ACCEPTED";
      const message      = await buildReceiverMessage(tamperedHash, id, status, nonce, timestamp);
      const sig          = await receiver.signMessage(ethers.getBytes(message));

      await dataAuth.connect(receiver).acknowledge(id, tamperedHash, status, nonce, timestamp, sig);
      expect((await dataAuth.records(id)).status).to.equal("TAMPERED");
    });

    it("allows REJECTED status", async function () {
      const content      = "Hello txt file";
      const id           = await doSendFile(content, 1);
      const receivedHash = hashFile(content);
      const nonce        = 10;
      const timestamp    = Math.floor(Date.now() / 1000);
      const status       = "REJECTED";
      const message      = await buildReceiverMessage(receivedHash, id, status, nonce, timestamp);
      const sig          = await receiver.signMessage(ethers.getBytes(message));

      await dataAuth.connect(receiver).acknowledge(id, receivedHash, status, nonce, timestamp, sig);
      expect((await dataAuth.records(id)).status).to.equal("REJECTED");
    });

    it("rejects if caller is not receiver", async function () {
      const content      = "Hello txt file";
      const id           = await doSendFile(content, 1);
      const receivedHash = hashFile(content);
      const nonce        = 10;
      const timestamp    = Math.floor(Date.now() / 1000);
      const status       = "ACCEPTED";
      const message      = await buildReceiverMessage(receivedHash, id, status, nonce, timestamp);
      const sig          = await stranger.signMessage(ethers.getBytes(message));

      await expect(dataAuth.connect(stranger).acknowledge(id, receivedHash, status, nonce, timestamp, sig))
        .to.be.revertedWith("Not the receiver");
    });

    it("rejects double acknowledgement", async function () {
      const content      = "Hello txt file";
      const id           = await doSendFile(content, 1);
      const receivedHash = hashFile(content);
      const timestamp    = Math.floor(Date.now() / 1000);
      const status       = "ACCEPTED";

      const msg1 = await buildReceiverMessage(receivedHash, id, status, 10, timestamp);
      const sig1 = await receiver.signMessage(ethers.getBytes(msg1));
      await dataAuth.connect(receiver).acknowledge(id, receivedHash, status, 10, timestamp, sig1);

      const msg2 = await buildReceiverMessage(receivedHash, id, status, 11, timestamp);
      const sig2 = await receiver.signMessage(ethers.getBytes(msg2));
      await expect(dataAuth.connect(receiver).acknowledge(id, receivedHash, status, 11, timestamp, sig2))
        .to.be.revertedWith("Already acknowledged");
    });
  });

  describe("getPendingForReceiver()", function () {
    it("returns pending IDs for receiver", async function () {
      await doSendFile("file one", 1);
      const pending = await dataAuth.connect(receiver).getPendingForReceiver();
      expect(pending.length).to.equal(1);
      expect(pending[0]).to.equal(0);
    });
  });

  describe("isNonceUsed()", function () {
    it("returns true after nonce is used", async function () {
      const fileHash  = hashFile("file");
      const nonce     = 42;
      const timestamp = Math.floor(Date.now() / 1000);
      const message   = await buildSenderMessage(fileHash, receiver.address, nonce, timestamp);
      const sig       = await sender.signMessage(ethers.getBytes(message));
      await dataAuth.connect(sender).sendFile(receiver.address, fileHash, nonce, timestamp, sig);

      expect(await dataAuth.isNonceUsed(sender.address, nonce)).to.equal(true);
      expect(await dataAuth.isNonceUsed(sender.address, 99)).to.equal(false);
    });
  });
});
