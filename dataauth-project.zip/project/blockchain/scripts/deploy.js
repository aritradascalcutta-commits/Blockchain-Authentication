const { ethers } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with wallet:", deployer.address);

  const DataAuth = await ethers.getContractFactory("DataAuth");
  const dataAuth = await DataAuth.deploy();
  await dataAuth.waitForDeployment();

  const address = await dataAuth.getAddress();
  console.log("DataAuth deployed to:", address);
  console.log("\nCopy this address into frontend/src/contracts/address.js");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
