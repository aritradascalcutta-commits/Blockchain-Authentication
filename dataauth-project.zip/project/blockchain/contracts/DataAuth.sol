// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol";

contract DataAuth {

    using ECDSA for bytes32;

    struct FileRecord {
        address sender;
        address receiver;
        bytes32 fileHash;
        uint256 timestamp;
        uint256 senderNonce;
        bytes   senderSig;
        string  status;
    }

    mapping(uint256 => FileRecord) public records;
    uint256 public recordCount;
    mapping(address => mapping(uint256 => bool)) private usedNonces;

    event FileSent(
        uint256 indexed id,
        address indexed sender,
        address indexed receiver,
        bytes32 fileHash,
        uint256 timestamp
    );

    event FileAcknowledged(
        uint256 indexed id,
        address indexed receiver,
        string  status
    );

    function sendFile(
        address  receiver,
        bytes32  fileHash,
        uint256  nonce,
        uint256  timestamp,
        bytes memory sig
    ) public {
        require(receiver != address(0), "Invalid receiver");
        require(!usedNonces[msg.sender][nonce], "Nonce already used");

        bytes32 message = keccak256(abi.encodePacked(
            fileHash, receiver, nonce, timestamp
        ));
        bytes32 ethSignedMessage = MessageHashUtils.toEthSignedMessageHash(message);
        address recovered = ECDSA.recover(ethSignedMessage, sig);
        require(recovered == msg.sender, "Invalid sender signature");

        usedNonces[msg.sender][nonce] = true;

        records[recordCount] = FileRecord({
            sender:      msg.sender,
            receiver:    receiver,
            fileHash:    fileHash,
            timestamp:   timestamp,
            senderNonce: nonce,
            senderSig:   sig,
            status:      "PENDING"
        });

        emit FileSent(recordCount, msg.sender, receiver, fileHash, timestamp);
        recordCount++;
    }

    function acknowledge(
        uint256  id,
        bytes32  receivedHash,
        string memory status,
        uint256  nonce,
        uint256  timestamp,
        bytes memory sig
    ) public {
        FileRecord storage record = records[id];

        require(msg.sender == record.receiver, "Not the receiver");
        require(
            keccak256(bytes(record.status)) == keccak256(bytes("PENDING")),
            "Already acknowledged"
        );
        require(
            keccak256(bytes(status)) == keccak256(bytes("ACCEPTED")) ||
            keccak256(bytes(status)) == keccak256(bytes("REJECTED")),
            "Invalid status"
        );
        require(!usedNonces[msg.sender][nonce], "Nonce already used");

        bytes32 message = keccak256(abi.encodePacked(
            receivedHash, id, status, nonce, timestamp
        ));
        bytes32 ethSignedMessage = MessageHashUtils.toEthSignedMessageHash(message);
        address recovered = ECDSA.recover(ethSignedMessage, sig);
        require(recovered == msg.sender, "Invalid receiver signature");

        usedNonces[msg.sender][nonce] = true;

        if (receivedHash != record.fileHash) {
            record.status = "TAMPERED";
            emit FileAcknowledged(id, msg.sender, "TAMPERED");
            return;
        }

        record.status = status;
        emit FileAcknowledged(id, msg.sender, status);
    }

    function getPendingForReceiver() public view returns (uint256[] memory) {
        uint256 count = 0;
        for (uint256 i = 0; i < recordCount; i++) {
            if (
                records[i].receiver == msg.sender &&
                keccak256(bytes(records[i].status)) == keccak256(bytes("PENDING"))
            ) count++;
        }
        uint256[] memory pending = new uint256[](count);
        uint256 idx = 0;
        for (uint256 i = 0; i < recordCount; i++) {
            if (
                records[i].receiver == msg.sender &&
                keccak256(bytes(records[i].status)) == keccak256(bytes("PENDING"))
            ) pending[idx++] = i;
        }
        return pending;
    }

    function isNonceUsed(address wallet, uint256 nonce) public view returns (bool) {
        return usedNonces[wallet][nonce];
    }
}
